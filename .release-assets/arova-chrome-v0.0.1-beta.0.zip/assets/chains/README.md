Chain assets retrieved 2026-09-05:
- Robinhood: https://pump.fun/chains/robinhood.png
- Solana/Ethereum/Base: https://github.com/trustwallet/assets/tree/master/blockchains (respective chain /info/logo.png)
- BNB Chain: https://raw.githubusercontent.com/trustwallet/assets/master/blockchains/smartchain/info/logo.png

Original brand assets, not generated logos. The same PNGs are bundled with the API for Telegram notification headers.
