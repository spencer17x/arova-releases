Platform icons sourced from the official websites on 2026-09-05:
- XXYY: https://www.xxyy.io/img/64.ico
- DeBot: https://debot.ai/favicon.ico
- GMGN: original favicon image embedded by the browser in the official https://gmgn.ai page favicon (without the browser automation overlay).

Used only to identify outbound platform links. Brand ownership remains with the respective platforms.
