import"./modulepreload-polyfill-B5Qt9EMX.js";window.location.replace(chrome.runtime.getURL("options.html")+"#account");
