Official source brand assets, retrieved 2026-09-05:
- Fomo: https://fomo.family/favicon.svg
- Pump: https://pump.fun/icon.png

Bundled locally to avoid runtime icon fetch failures. Telegram uses the existing icon library's Telegram brand mark. Brand ownership remains with the respective platforms.

- GigaX: https://gigax.fun/assets/logo-CElvZlIR.png (official site icon, retrieved 2026-09-17). Used for source filters, notification attribution and the connection card.
